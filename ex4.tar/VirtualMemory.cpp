#include "VirtualMemory.h"
#include "PhysicalMemory.h"
#include <cmath>
#include <algorithm>

void clearTable(uint64_t frameIndex) {
    for (uint64_t i = 0; i < PAGE_SIZE; ++i) {
        PMwrite(frameIndex * PAGE_SIZE + i, 0);
    }
}

void VMinitialize() {
    for (int i = 0; i < NUM_FRAMES; ++i) {
        clearTable((uint64_t) i);
    }
}

/**
 * computes the cyclic distance between page p1 and page p2 according to the given formula
 * @return return the answer
 */
uint64_t cyclic_distance(uint64_t p1, uint64_t p2) {
    uint64_t _min = (uint64_t) std::min((int) NUM_PAGES - abs((int) (p1 - p2)), abs((int) (p1 - p2)));
    return _min;
}

/**
 * in case we need to evict a page in order to insert one, this function finds the appropriate page.
 * @param insert_page- the page to insert
 * @param depth- gets called with 0, changes during recursion
 * @param cur_frame- gets called with 0, changes during recursion
 * @param cur_page- gets called with 0, changes during recursion
 * @param best_page- gets called with 0, changes during recursion
 * @return the furthest page according to the given formula
 */
uint64_t
find_page_to_evict(uint64_t insert_page, int depth, uint64_t cur_frame, uint64_t cur_page, uint64_t best_page) {
    if (depth == TABLES_DEPTH) {
        return cur_page;
    }
    word_t next_frame;
    uint64_t physical_addr;
    uint64_t option_page;
    for (int i = 0; i < PAGE_SIZE; ++i) {
        physical_addr = cur_frame * PAGE_SIZE + i;
        PMread(physical_addr, &next_frame);
        if (next_frame) {
            option_page = find_page_to_evict(insert_page, depth + 1, (uint64_t) next_frame,
                                             (cur_page << OFFSET_WIDTH) + i, best_page);
            if (option_page != insert_page) {
                if (best_page == insert_page) {
                    best_page = option_page;
                } else if (cyclic_distance(option_page, insert_page) > cyclic_distance(best_page, insert_page)) {
                    best_page = option_page;
                }
            }
        }
    }
    return best_page;
}

/**
 * this function updates the direction table according to the remainder
 */
void update_directions_table(uint64_t remainder, uint64_t *directions_table) {
    for (int i = TABLES_DEPTH - 1; i >= 0; --i) {
        directions_table[i] = remainder % PAGE_SIZE;
        remainder = remainder / PAGE_SIZE;
    }
}

/**
 * this function evicts the right page according to the find_page_to_evict function
 * @param page_2_insert- page to insert.
 * @return- available frame
 */
word_t evict_frame(uint64_t page_2_insert) {
    uint64_t page_to_evict = find_page_to_evict(page_2_insert, 0, 0, 0, page_2_insert);
    uint64_t directions_table[TABLES_DEPTH] = {0};
    update_directions_table(page_to_evict, directions_table);
    word_t frame = 0;
    word_t prev_frame = 0;
    for (int i = 0; i < TABLES_DEPTH; ++i) {
        prev_frame = frame;
        PMread(frame * PAGE_SIZE + directions_table[i], &frame);
    }
    PMevict((uint64_t) frame, page_to_evict);
    clearTable((uint64_t) frame);
    PMwrite(prev_frame * PAGE_SIZE + directions_table[TABLES_DEPTH - 1], 0);
    return frame;
}

/**
 * a recursive function. this function checks if a frame is a page with data. in addition, it updates the pointers
 * between frames.
 * @param frame- the frame to check whether it is a leaf (=page)
 * @param start- get called with 0, changes according to the tree traversing
 * @param depth- gets increased every recursive call
 * @return 1 if frame is a leaf, 0 else
 */
int is_leaf(uint64_t frame, uint64_t start, int depth) {
    if (depth == TABLES_DEPTH) {
        if (frame == start) {
            return 1;
        } else {
            return 0;
        }
    }
    word_t next_frame;
    uint64_t physical_addr;
    int final = 0;
    for (int i = 0; i < PAGE_SIZE; ++i) {
        physical_addr = (uint64_t) start * PAGE_SIZE + i;
        PMread(physical_addr, &next_frame);
        if (((uint64_t) next_frame == frame) && (depth < TABLES_DEPTH - 1)) {
            PMwrite(physical_addr, 0);
            return 0;
        }
        if (next_frame) {
            final += is_leaf(frame, (uint64_t) next_frame, depth + 1);
        }
    }
    return final;
}

/**
 * @param cur_frame- the frame that we need a frame to point to
 * @return the minimal available frame, if it exists. else, 0.
 */
word_t find_available_frame(uint64_t cur_frame) {
    word_t next_frame;
    uint64_t physical_addr;
    for (uint64_t i = 1; i < NUM_FRAMES; ++i) {
        if (i != cur_frame) {
            bool isClear = true;
            for (int j = 0; j < PAGE_SIZE; ++j) {
                physical_addr = (uint64_t) i * PAGE_SIZE + j;
                PMread(physical_addr, &next_frame);
                if (next_frame) {
                    isClear = false;
                }
            }
            if (isClear) {
                if (!is_leaf((uint64_t) i, 0, 0)) {
                    return (word_t) i;
                }
            }
        }
    }
    return 0;
}

/**
 * this function handles the case in which the wanted frames or page does not exist in the tree, and creates it.
 * this function is recursive.
 * @param directions_table- the turns one must take in the virtual tree in order to get to the right page
 * @param page_number- page to write to
 * @param cur_depth- get called with 0, changes while recursion
 * @param cur_frame- the current frame of the current recursive call
 * @return- the physical address before the offset inside the page
 */
uint64_t build_physical_address(uint64_t *directions_table, uint64_t page_number, int cur_depth, uint64_t cur_frame) {
    if (cur_depth == TABLES_DEPTH) {
        PMrestore(cur_frame, page_number);
        return cur_frame;
    }
    word_t available_frame = find_available_frame(cur_frame);
    if (!available_frame) {
        available_frame = evict_frame(page_number);
    }
    uint64_t physical_addr = (cur_frame * PAGE_SIZE) + directions_table[cur_depth];
    PMwrite(physical_addr, available_frame);
    return build_physical_address(directions_table, page_number, cur_depth + 1, (uint64_t) available_frame);
}

/**
 * A recursive function. If a frame exists in the right place, this function will find it. else, it will create it
 * using build_physical_address
 * @param directions_table- the turns one must take in the virtual tree in order to get to the right page
 * @param page_number- page to write to
 * @param start_depth- get called with 0, changes while recursion
 * @param cur_frame- the current frame of the current recursive call
 * @return- the physical address before the offset inside the page
 */
uint64_t find_physical_address(uint64_t *directions_table, uint64_t page_number, int start_depth, uint64_t cur_frame) {
    if (start_depth == TABLES_DEPTH) {
        return cur_frame;
    }
    word_t next_frame;
    uint64_t physical_addr = (cur_frame * PAGE_SIZE) + directions_table[start_depth];
    PMread(physical_addr, &next_frame);
    if (next_frame) {
        return find_physical_address(directions_table, page_number, start_depth + 1, (uint64_t) next_frame);
    }
    return build_physical_address(directions_table, page_number, start_depth, cur_frame);
}

/**
 * @param virtualAddress- the inputed virtual address
 * @return the offset of the frame (the index inside the page)
 */
uint64_t get_offset(uint64_t virtualAddress) {
    return virtualAddress % PAGE_SIZE;
}

/**
 * @param virtualAddress- the inputed virtual address
 * @return the correct physical address to write to.
 */
uint64_t get_final_address(uint64_t virtualAddress) {
    uint64_t remainder = (virtualAddress / PAGE_SIZE);
    uint64_t directions_table[TABLES_DEPTH] = {0};
    update_directions_table(remainder, directions_table);
    return find_physical_address(directions_table, remainder, 0, 0) * PAGE_SIZE + get_offset(virtualAddress);
}

/**
 * checks validity of the input virtualAddress
 * @param virtualAddress- the input to VMread and VMwrite
 * @return true iff virtualAddress < VIRTUAL_MEMORY_SIZE, else otherwise
 */
bool validity_check(uint64_t virtualAddress) {
    return !(bool) (virtualAddress >= VIRTUAL_MEMORY_SIZE);
}

int VMread(uint64_t virtualAddress, word_t *value) {
    if (!validity_check(virtualAddress)) { return 0; }
    PMread(get_final_address(virtualAddress), value);
    return 1;
}

int VMwrite(uint64_t virtualAddress, word_t value) {
    if (!validity_check(virtualAddress)) { return 0; }
    PMwrite(get_final_address(virtualAddress), value);
    return 1;
}